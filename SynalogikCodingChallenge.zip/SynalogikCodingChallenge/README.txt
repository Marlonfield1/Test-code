Instructions to run:

1. Extract the contents of the ZIP file
2. Open a command prompt inside of the CodingChallenge file and run the command mvn spring-boot:run
3. Open a web browser and go to localhost:8080/files?textfile="filename" where filename is the name of the file 
   you want the application to read.  The file must be in the main SynalogikCodingChallenge folder in order to be read
4. To run the test, in the command prompt run the command mvn package